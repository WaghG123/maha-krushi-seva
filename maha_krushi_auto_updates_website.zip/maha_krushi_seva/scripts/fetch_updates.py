#!/usr/bin/env python3
"""Build updates.json from Google News RSS queries. Headlines are pointers, not official verification."""
import json, re, urllib.request, urllib.parse, xml.etree.ElementTree as ET
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from html import unescape
from pathlib import Path

QUERIES = [
    ("SCHEME", "Maharashtra government scheme OR Maharashtra farmer scheme"),
    ("AGRI", "India agriculture ministry farmer scheme notification"),
    ("JOBS", "Maharashtra government recruitment notification"),
]
def clean(value):
    return re.sub(r"\\s+", " ", unescape(re.sub(r"<[^>]+>", "", value or ""))).strip()
def fetch(query, category):
    url = "https://news.google.com/rss/search?" + urllib.parse.urlencode({"q":query,"hl":"en-IN","gl":"IN","ceid":"IN:en"})
    req = urllib.request.Request(url, headers={"User-Agent":"MahaKrushiSevaInfoSite/1.0"})
    with urllib.request.urlopen(req, timeout=25) as response:
        root = ET.fromstring(response.read())
    items=[]
    for item in root.findall("./channel/item")[:5]:
        title=clean(item.findtext("title")); link=clean(item.findtext("link"))
        source_node=item.find("source"); source=clean(source_node.text if source_node is not None else "")
        published=clean(item.findtext("pubDate"))
        try: published=parsedate_to_datetime(published).astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        except Exception: pass
        if title and link: items.append({"category":category,"title":title,"link":link,"source":source,"published":published})
    return items
def main():
    items=[]; seen=set()
    for category,query in QUERIES:
        try:
            for item in fetch(query,category):
                if item["link"] not in seen: seen.add(item["link"]); items.append(item)
        except Exception as exc: print(f"Feed warning for {category}: {exc}")
    payload={"generated_at":datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
             "notice":"Headlines are automatically collected and must be verified at official sources.","items":items}
    Path("updates.json").write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding="utf-8")
    print(f"Wrote {len(items)} headlines to updates.json")
if __name__=="__main__": main()
